<div class="eltdf-single-show-date">
    <h1> <?php echo get_the_date('d'); ?> </h1>
    <h6> <?php echo get_the_date('F'); ?> </h6>
</div>
