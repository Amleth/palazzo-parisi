<div class="eltdf-rs-image-holder">
    <?php the_post_thumbnail(); ?>
</div>
