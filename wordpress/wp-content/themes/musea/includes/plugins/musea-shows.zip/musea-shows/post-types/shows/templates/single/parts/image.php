<div class="eltdf-single-show-image">
    <?php the_post_thumbnail('full') ?>
</div>