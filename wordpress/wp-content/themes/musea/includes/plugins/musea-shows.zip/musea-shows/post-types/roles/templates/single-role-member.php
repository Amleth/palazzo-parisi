<?php

get_header();

musea_elated_get_title();

do_action('musea_elated_action_before_main_content');

musea_shows_get_single_roles();

get_footer();