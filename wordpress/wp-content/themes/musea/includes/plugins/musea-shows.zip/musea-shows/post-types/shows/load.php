<?php

include_once MUSEA_SHOWS_CPT_PATH . '/shows/shows-register.php';
include_once MUSEA_SHOWS_CPT_PATH . '/shows/helper-functions.php';