<?php if($query_results->max_num_pages > 1) { ?>
	<div class="eltdf-sl-loading">
		<div class="eltdf-sl-loading-bounce1"></div>
		<div class="eltdf-sl-loading-bounce2"></div>
		<div class="eltdf-sl-loading-bounce3"></div>
	</div>
<?php }