<div class="eltdf-show-info-item eltdf-show-content-item">
    <?php the_content(); ?>
</div>