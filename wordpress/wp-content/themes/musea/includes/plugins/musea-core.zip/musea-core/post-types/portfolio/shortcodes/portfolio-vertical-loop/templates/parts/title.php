<div itemprop="name" class="eltdf-pvli-title entry-title">
    <?php echo esc_attr(get_the_title()); ?>
</div>
