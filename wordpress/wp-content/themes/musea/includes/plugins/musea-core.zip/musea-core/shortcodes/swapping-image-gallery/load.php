<?php

include_once MUSEA_CORE_SHORTCODES_PATH . '/swapping-image-gallery/functions.php';
include_once MUSEA_CORE_SHORTCODES_PATH . '/swapping-image-gallery/swapping-image-gallery.php';