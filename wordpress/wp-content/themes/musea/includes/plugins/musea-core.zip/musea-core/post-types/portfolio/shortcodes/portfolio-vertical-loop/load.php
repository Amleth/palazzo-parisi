<?php

require_once 'portfolio-vertical-loop.php';
require_once 'helper-functions.php';